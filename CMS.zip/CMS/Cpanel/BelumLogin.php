<?php
echo '<script type="text/javascript">
alert("./Dilarang! :( \n./Harap Login / Membuat Akun terlebih Dahulu! ^_^ ");
</script>';
echo '<meta http-equiv="refresh" content="0; url=../Cpanel" />';
?>